a=input('enter a vlaue:\n')
b=input('\nenter b value:\n')
c=input('enter c vlaue:\n')
d=a*b*c
print "\nproduct of %s *%s *%s is : %s" %(a,b,c,d)

