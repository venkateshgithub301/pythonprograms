import pudb
pudb.set_trace()
for letter in 'abcd':
	if(letter == 'c'):
		continue
	print(letter)
