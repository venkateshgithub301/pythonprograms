a=input("enter the number: ")
if a%2==0:
	print "its even"
else:
	print "its odd"

print "out of the block"
