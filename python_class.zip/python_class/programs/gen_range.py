a=input("enter the number: ")
b=range(1,a,3)
print b
