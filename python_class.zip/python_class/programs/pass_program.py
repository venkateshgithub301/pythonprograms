import pudb
pudb.set_trace()
sequence = range(4)
for val in sequence:
	pass
