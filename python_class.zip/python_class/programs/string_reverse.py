s = raw_input('enter the string')
count = len(s)-1
for i in s:
	print s[count]
	count = count - 1
