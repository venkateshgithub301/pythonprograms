import pudb
pudb.set_trace()
for i in range(2,10,2):
	if (i==6): 
		break
	print(i)
print("end of program")
