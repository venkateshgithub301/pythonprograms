a=input('Enter the value')
if a%2==0:
	print "Even"
	print 'if block'
else:
	print "Odd"
	print 'else block'

print "out of if else block"









