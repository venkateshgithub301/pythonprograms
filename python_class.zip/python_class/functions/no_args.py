import pudb

def fun1():
	pudb.set_trace()
	print "hello"


fun1()